import Vue from 'vue';
import Vuex from 'vuex';
import App from './App.vue';
import store from './store';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap';

Vue.use(Vuex);
Vue.config.productionTip = false

 new Vue({
  render: h => h(App),
  store: new Vuex.Store(store),
}).$mount('#app')


/*  const app = createApp(App);*/

