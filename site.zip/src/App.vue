<template>
  <div id="app">
    <MainHeader/>
    <component :is="currentComponent" @navigate="navigate"></component>
    <MainFooter/>
  </div>
</template>

<script>
import MainFooter from './components/MainFooter.vue';
import MainHeader from './components/MainHeader.vue';
import MainPage from './components/MainPage.vue';
import MainProject from './components/MainProject.vue';
import ProjectDetails from './components/ProjectDetails.vue';


export default {
  name: 'App',
  components: {
    MainPage,
    MainHeader,
    MainFooter,
    MainProject,
    ProjectDetails
  },
  data() {
    return {
      currentComponent: MainPage
    };
  },
  methods: {
    navigate(page) {
      if (page === 'MainProject') {
        this.currentComponent = MainProject;
      } else if (page === 'MainPage') {
        this.currentComponent = MainPage;
      } else if (page === 'ProjectDetails'){
        this.currentComponent = ProjectDetails;
      }
    }
  }
}
</script>

<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
