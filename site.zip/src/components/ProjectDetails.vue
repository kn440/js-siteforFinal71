<template>
    <div class="project-details">
        <div class="s21container">
            <img src="../assets/img/s2/DetailBanner.png">
        </div>
        <div class="s22container"> <div class="s22container__text">
            <span class="s22container__text__up__title">{{ project.title }}</span>
      <p>{{ project.description }}</p>
    </div></div>
      <div id="carouselExampleCaptions" class="carousel slide">
        <div class="carousel-inner">
          <div v-for="(image, index) in project.images" :key="index" :class="['carousel-item', { active: index === 0 }]">
            <img :src="image" class="d-block sizeimg" :alt="'Slide ' + (index + 1)" />
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </div>
  </template>
  
  <script>
  import { mapGetters } from 'vuex';
  
  export default {
    name: 'ProjectDetails',
    methods: {
        goToHome() {
        this.$emit('navigate', 'MainPage');
        },
    },
    computed: {
      ...mapGetters(['getProject']),
      project() {
        return this.getProject;
      },
    },
  };
  </script>
  
  <style scoped lang="scss">
    @import '../assets/filesforstyle/vars';

    .s22container{
        @include ParamWHM(1200px, 200px, 430px, none, none, none);
        @include ParamPosition(none, flex, center, none);
        margin-bottom: 100px;
        &__text{
            @include ParamWHM(658px, $heightS22, none, none, none, none);
            @include ParamPosition(none, flex, none, none);
            background-color:$colortotal;
            border-top-left-radius: 10%;
            border-top-right-radius: 10%;
            flex-direction: column;
            align-items: center;
            padding: 0px;
            gap: 12px;
            

            &__up{
                margin-top: 30px;
                width: 362px;
               
                &__title {
                    @include ParamText(#222, Jost, 50px, 400, none, center);   
                } 
            }
      }
      
      }

 .carousel-control-prev{
        left: 12%;
      }
      .carousel-control-next{
        right: 30%;
      }

  .carousel-item img {
    width: 1200px;
    height: auto;
  }
  .sizeimg{
    margin-left: 400px;
    width: 1200px;
    height: 800px;
    border-radius: 10%;
  }
  .s21container{
    @include ParamWHM($widthS21, $heightS21, none, none, none, none);
  
  }
  </style>
  